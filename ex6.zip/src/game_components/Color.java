package game_components;

/**
 * enum of colors
 */
public enum Color {
  BLACK, WHITE
}
