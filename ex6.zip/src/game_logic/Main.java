package game_logic;

public class Main {

  public static void main(String[] args) {
    GameSetUp g = new GameSetUp();
    g.playGame();
  }
}
